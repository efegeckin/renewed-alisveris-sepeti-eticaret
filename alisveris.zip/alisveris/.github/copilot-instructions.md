# Copilot instructions for `alisveris`

## Project profile

This is a server-rendered PHP 8.2 e-commerce demo running under XAMPP/Apache with MariaDB/MySQL. There is no Composer, npm, PHPUnit, or CI configuration in the repository. The application is normally available at `http://localhost/alisveris/`.

## Build, test, and validation commands

There is no build step. PHP files can be syntax-checked with the PHP executable shipped by XAMPP:

```powershell
& 'C:\xampp\php\php.exe' -l 'C:\xampp\htdocs\alisveris\detay.php'
```

Check every application PHP file:

```powershell
$files = Get-ChildItem 'C:\xampp\htdocs\alisveris' -Recurse -Filter *.php
foreach ($file in $files) {
  & 'C:\xampp\php\php.exe' -l $file.FullName
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
```

Check only the admin area:

```powershell
$files = Get-ChildItem 'C:\xampp\htdocs\alisveris\admin' -Recurse -Filter *.php
foreach ($file in $files) {
  & 'C:\xampp\php\php.exe' -l $file.FullName
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
```

Use HTTP smoke tests only with Apache and MariaDB running:

```powershell
Invoke-WebRequest -UseBasicParsing 'http://localhost/alisveris/index.php'
Invoke-WebRequest -UseBasicParsing 'http://localhost/alisveris/telefon.php'
```

For authenticated pages, use a browser or a persistent HTTP session. Admin pages must redirect unauthenticated users to `login.php`; a `200` response from `Invoke-WebRequest` can still mean the final response is the login page, so inspect `BaseResponse.ResponseUri`.

The `test/` directory contains old standalone practice scripts connected to a separate `deneme` database. Do not treat those scripts as the application's test suite or use them to validate the production `alisveris` flow.

## Architecture

- Root PHP files are the storefront and account flows:
  - `index.php` is the landing page.
  - `telefon.php` is the catalog/search page.
  - `detay.php` resolves a product and its model/color/memory variant, then handles add-to-cart.
  - `sepet.php`, `profil.php`, `odeme.php`, `odeme_tamamla.php`, and `siparisler.php` implement the authenticated cart, account, checkout, order creation, and order history flows.
  - `login.php`, `register.php`, and `logout.php` own authentication.
- `parts/` contains storefront layout fragments and address endpoints. `parts/header.php` calculates the cart badge, account menu, category navigation, and the admin link from the session.
- `admin/` is a separate server-rendered management area. Every admin entry point includes `admin/baglanti.php` and calls `checkAdmin()`.
- `admin/a-parts/` contains the admin document head, sidebar, top bar, and footer. The sidebar and top bar are shared by all admin screens; update these shared fragments rather than duplicating navigation markup.
- `assets/css/` contains page-level CSS. `style.css` is the storefront system, `account.css` covers account/checkout pages, `auth.css` covers login/register, and `admin.css` covers the admin shell and catalog/dashboard screens.
- `assets/js/` contains small vanilla-JS behaviors. `app.js` handles address lookup and shared storefront interactions; `auth.js` handles password visibility; `admin.js` is currently intentionally minimal.
- `sql/alisveris.sql` is the database dump. `sql/upgrade_accounts.sql` is the migration for the `kullanici.password` column required by bcrypt hashes.
- The database connection is centralized in `admin/baglanti.php`, using database `alisveris`, user `root`, an empty password, and `utf8mb4`.

## Authentication and authorization conventions

- Session keys used by the application are `kullanici_id`, `admin` (display username), and `rol`.
- `checkAuth()` means any signed-in user; `checkAdmin()` requires both `kullanici_id` and `rol === 'admin'`.
- Do not authorize based only on the presence of `$_SESSION['admin']`; use `checkAdmin()` for admin routes.
- Admin pages must remain locked after logout and must redirect to `../login.php`.
- Login supports legacy short/plain-text demo passwords and upgrades a successful legacy password to bcrypt. New registrations must use `password_hash()`.
- The password column must remain wide enough for bcrypt (`VARCHAR(255)`); do not restore the old `VARCHAR(50)` schema.

## Database and query conventions

- Existing tables use Turkish names and fields, including `telefon`, `model`, `renkler`, `hafiza`, `stok_durumu`, `kategori`, `sepet`, `kullanici`, and address tables.
- Use JOINs for product display data instead of one query per row. Product records commonly need model, color, memory, and stock joins.
- Use prepared statements for user-controlled values and write operations. Cast integer IDs and numeric quantities before use.
- Escape rendered values with `htmlspecialchars()`, including product names, seller text, messages, and session-derived display values.
- Product stock is represented by both `stok_id` and `stok_adet`; a product is not available when its stock status is the sold-out status (`stok_id = 2`) or its quantity is zero.
- Cart mutations must include the current `kullanici_id` in their lookup/update/delete conditions. Never allow one user's cart item to be changed by another user.
- Checkout totals must be calculated from the current cart/database values, not from a hidden form total or a hard-coded amount.
- `siparisler` may be created lazily by the existing order flow; code that reads it should account for installations where the table has not yet been created.

## Admin UI conventions

- The admin shell uses a fixed 240px sidebar on desktop and a slide-out sidebar on small screens. Content must use the shared `.content` layout and must not add a second sidebar or hard-coded overlapping margins.
- Shared CSS is loaded from `admin/a-parts/head.php`; cache-busting query strings are used when updating `admin.css`.
- The refreshed admin UI uses the `admin-*` class namespace, purple accent `#635bff`, dark sidebar `#17172a`, and card-based layouts. New admin screens should reuse these classes and the shared top bar.
- Active sidebar state is computed from `basename($_SERVER['PHP_SELF'])`; preserve special query-state handling such as the low-stock view when adding navigation entries.
- Product management belongs in `admin/telefon.php` and `admin/telefon_ekle.php`. Keep search/filter controls, product image, variant, price, stock state, and a safe POST delete action consistent with the existing catalog screen.
- Do not reintroduce the old Bootstrap table/dropdown markup as the primary admin layout; legacy rules in `admin.css` are overridden by final scoped rules at the end of the file.

## File and change boundaries

- Prefer shared fragments and existing helpers before adding duplicate PHP or JavaScript.
- Keep storefront, account, and admin styles separated by their existing CSS files.
- Preserve the current Turkish UI language and existing database column names.
- Do not change database credentials or commit secrets.
- When changing schema assumptions, update the relevant SQL file and explain the required import/migration in the change.
- Avoid deleting old files unless references have been searched first; some legacy fragments are still present even when the main flow no longer includes them.
